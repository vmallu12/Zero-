# Atyro VM Discord Manager

A Discord bot for managing multiple `hopingboyz/atyro-ubuntu24` Docker/KVM VMs.

## Features

- `!vm RAM CPU DISK @user`
- Multiple independent VMs
- Automatic unique SSH/VNC ports
- 28-day expiry
- `!renew @user`
- `!delete @user`
- `!manage [@user]`
- Owner-only SSHX and OS reinstall buttons
- `!setadmin @user`
- `!removeadmin @user`
- `!vminfo`
- CPU/RAM/disk usage
- KVM/QEMU information
- SQLite persistence
- Professional embeds and supplied custom emoji IDs
- Automatic expiry stopping
- Owner DM notifications

## Important security note

This bot has direct Docker access. Anyone who receives Discord admin access through the bot can create/delete/manage VMs. Protect the bot token and VPS.

The bot must run on the Docker host or on a machine with `/var/run/docker.sock` access.

## 1. Discord bot setup

Create a Discord application and bot.

Enable:
- Message Content Intent
- Server Members Intent

Invite it with permissions appropriate for your management channel, including:
- Send Messages
- Embed Links
- Read Message History
- Use External Emojis
- Manage Messages (optional)

## 2. Install

On the VPS:

```bash
apt update
apt install -y python3 python3-venv
mkdir -p /opt/atyro-bot
cd /opt/atyro-bot
```

Copy the project files there.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Put the Discord token into `.env`.

## 3. Test Docker access

```bash
docker version
docker image inspect hopingboyz/atyro-ubuntu24
ls -l /var/run/docker.sock
```

Then:

```bash
source .venv/bin/activate
python bot.py
```

You should see:

```text
Logged in as ...
```

## 4. Commands

Admin:

```text
!vm 2 1 50 @user
!renew @user
!delete @user
!manage @user
!vminfo
!setadmin @user
!removeadmin @user
```

Owner:

```text
!manage
```

Owner management buttons:

- SSHX
- Reinstall OS
- Refresh

## 5. SSHX

The image currently does not contain `tmate` or `sshx`; the check you performed only returned `/usr/bin/curl`.

Therefore the bot installs SSHX inside the VM on first SSHX request:

```text
curl -fsSL https://sshx.io/get | sh
```

and then starts `sshx`.

If the SSHX provider changes its installer/CLI, update the SSHX command in `OwnerVMView.sshx()` in `bot.py`.

## 6. Reinstall behavior

Reinstall:

1. Stops/removes the current VM container.
2. Removes its `/vm` volume.
3. Creates a fresh volume with the same name.
4. Creates a new container using the same RAM/CPU/disk values.
5. Keeps the existing `expires_at` unchanged.

This is destructive. The confirmation button is intentional.

## 7. Port behavior

The first VM normally uses:

```text
SSH 2026
VNC 6080
```

The next VM gets the next available ports.

Do not expose Docker's socket to untrusted users.

## 8. Running with Docker Compose

Build/start:

```bash
docker compose up -d --build
```

Logs:

```bash
docker compose logs -f atyro-discord-bot
```

Stop:

```bash
docker compose down
```

## 9. Running without Compose

```bash
source .venv/bin/activate
nohup python bot.py > bot.log 2>&1 &
```

For production, Docker Compose is recommended.

## 10. First test

After the bot is online, use an administrator account:

```text
!vm 2 1 50 @youruser
```

Then:

```text
!manage
```

The VM should appear with:

```text
2 GB RAM
1 CPU
50 GB disk
KVM / QEMU
SSH port
VNC port
28-day expiry
```

## Discord permissions and automatic roles

- Main bot administrator: `1447083500720230401` (always treated as Atyro admin).
- VM owner role: `1545501965562159116` — automatically granted after successful VM creation.
- Atyro bot-admin role: `1546053390528811120` — automatically granted by `!adminset @user` / `!setadmin @user`, and removed by `!removeadmin @user`.
- `!adminset @user` is an alias for `!setadmin @user`.
- Atyro commands beginning with `!` used by an Atyro admin or VM owner receive the animated `GG` reaction `<a:GG:1519587770425933824>`.

Make sure the bot has **Manage Roles** permission and its highest role is above both automatic roles in the Discord server role hierarchy.
